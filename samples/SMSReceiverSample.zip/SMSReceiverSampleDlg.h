// SMSReceiverSampleDlg.h : header file
//

#if !defined(AFX_SMSRECEIVERSAMPLEDLG_H__2E333043_FBF4_4213_9725_490196E3BE92__INCLUDED_)
#define AFX_SMSRECEIVERSAMPLEDLG_H__2E333043_FBF4_4213_9725_490196E3BE92__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define TIMER_FILLLIST	74

class CSMSReceiver;


/////////////////////////////////////////////////////////////////////////////
// CSMSReceiverSampleDlg dialog

class CSMSReceiverSampleDlg : public CDialog
{
// Construction
public:
	CSMSReceiverSampleDlg(CWnd* pParent = NULL);	// standard constructor

	static void ReceptionFinished(DWORD dwCookie, CStringList& slMessages);

	void FillList(CStringList& slMessages);
	void DelReception();

// Dialog Data
	//{{AFX_DATA(CSMSReceiverSampleDlg)
	enum { IDD = IDD_SMSRECEIVERSAMPLE_DIALOG };
	CEdit	m_edMessages;
	CString	m_csServer;
	CString	m_csLogin;
	CString	m_csPassword;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSMSReceiverSampleDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	CSMSReceiver* m_pRSMS;

	// Generated message map functions
	//{{AFX_MSG(CSMSReceiverSampleDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SMSRECEIVERSAMPLEDLG_H__2E333043_FBF4_4213_9725_490196E3BE92__INCLUDED_)
