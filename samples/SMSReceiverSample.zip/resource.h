//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SMSReceiverSample.rc
//
#define IDD_SMSRECEIVERSAMPLE_DIALOG  	102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_SERVER                    	1001
#define IDC_LOGIN                       1002
#define IDC_PASSWORD                    1003
#define IDC_MESSAGES                    1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
