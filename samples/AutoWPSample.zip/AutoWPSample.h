// AutoWPSample.h : main header file for the AUTOWPSAMPLE application
//

#if !defined(AFX_AUTOWPSAMPLE_H__ADD128B5_D5C9_407E_8503_0A7874BBD869__INCLUDED_)
#define AFX_AUTOWPSAMPLE_H__ADD128B5_D5C9_407E_8503_0A7874BBD869__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CAutoWPSampleApp:
// See AutoWPSample.cpp for the implementation of this class
//

class CAutoWPSampleApp : public CWinApp
{
public:
	CAutoWPSampleApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAutoWPSampleApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CAutoWPSampleApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AUTOWPSAMPLE_H__ADD128B5_D5C9_407E_8503_0A7874BBD869__INCLUDED_)
