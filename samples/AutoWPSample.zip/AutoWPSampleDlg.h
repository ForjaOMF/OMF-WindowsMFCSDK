// AutoWPSampleDlg.h : header file
//

#if !defined(AFX_AUTOWPSAMPLEDLG_H__428C80D3_2703_4B7F_A8EF_EA0015A2AB78__INCLUDED_)
#define AFX_AUTOWPSAMPLEDLG_H__428C80D3_2703_4B7F_A8EF_EA0015A2AB78__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CAutoWPSampleDlg dialog

class CAutoWPSampleDlg : public CDialog
{
// Construction
public:
	CAutoWPSampleDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CAutoWPSampleDlg)
	enum { IDD = IDD_AUTOWPSAMPLE_DIALOG };
	CString	m_csLogin;
	CString	m_csPassword;
	CString	m_csURL;
	CString	m_csText;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAutoWPSampleDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CAutoWPSampleDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AUTOWPSAMPLEDLG_H__428C80D3_2703_4B7F_A8EF_EA0015A2AB78__INCLUDED_)
