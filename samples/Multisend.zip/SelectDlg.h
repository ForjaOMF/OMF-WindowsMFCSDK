#pragma once
#include "afxwin.h"


// Cuadro de di�logo de CSelectDlg

class CSelectDlg : public CDialog
{
	DECLARE_DYNAMIC(CSelectDlg)

public:
	CSelectDlg(CWnd* pParent = NULL);   // Constructor est�ndar
	virtual ~CSelectDlg();

	bool	m_bTelephone;
	bool	m_bEmail;

// Dialog box data
	enum { IDD = IDD_SELECT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // Compatibilidad con DDX o DDV

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CString m_csOption;
	CComboBox m_cOptions;
	afx_msg void OnBnClickedOk();
};
