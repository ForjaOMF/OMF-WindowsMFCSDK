//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Multisend.rc
//
#define IDC_SEND                        3
#define IDC_SEND2                       4
#define IDD_MULTISEND_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDR_CONTACTS                    129
#define IDD_SELECT                      133
#define IDC_LIST                        1000
#define IDC_USER                        1001
#define IDC_PASSWORD                    1002
#define IDC_MESSAGE                     1003
#define IDC_DESTINATION                 1004
#define IDC_REFRESH                     1005
#define IDS_STATUS                      1007
#define IDC_SUBJECT                     1008
#define IDC_PATHIMG                     1010
#define IDC_BROWSEIMG                   1011
#define IDC_PATHSND                     1012
#define IDC_COMBO1                      1012
#define IDC_OPTIONS                     1012
#define IDC_BROWSESND                   1013
#define IDC_PATHVID                     1014
#define IDC_BROWSEVID                   1015
#define ID_BUTTON32774                  32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
