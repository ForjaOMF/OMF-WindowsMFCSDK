// MultisendDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Multisend.h"
#include "MultisendDlg.h"

#include "Copiagenda.h"
#include "SMSSender.h"
#include "MMSSender.h"
#include ".\Multisenddlg.h"

#include "SelectDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMultisendDlg dialog

CMultisendDlg::CMultisendDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMultisendDlg::IDD, pParent)
	, m_csSubject(_T(""))
	, m_csPathImg(_T(""))
	, m_csPathSnd(_T(""))
	, m_csPathVid(_T(""))
{
	//{{AFX_DATA_INIT(CMultisendDlg)
	m_csUser = _T("");
	m_csPassword = _T("");
	m_csMessage = _T("");
	m_csDestination = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_pmsoAddressBook = NULL;
}

void CMultisendDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMultisendDlg)
	DDX_Control(pDX, IDC_LIST, m_cList);
	DDX_Text(pDX, IDC_USER, m_csUser);
	DDX_Text(pDX, IDC_PASSWORD, m_csPassword);
	DDX_Text(pDX, IDC_MESSAGE, m_csMessage);
	DDX_Text(pDX, IDC_DESTINATION, m_csDestination);
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_SUBJECT, m_csSubject);
	DDX_Text(pDX, IDC_PATHIMG, m_csPathImg);
	DDX_Text(pDX, IDC_PATHSND, m_csPathSnd);
	DDX_Text(pDX, IDC_PATHVID, m_csPathVid);
}

BEGIN_MESSAGE_MAP(CMultisendDlg, CDialog)
	//{{AFX_MSG_MAP(CMultisendDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_REFRESH, OnRefresh)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_SEND, OnSend)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BROWSEIMG, OnBnClickedBrowseimg)
	ON_BN_CLICKED(IDC_BROWSESND, OnBnClickedBrowsesnd)
	ON_BN_CLICKED(IDC_BROWSEVID, OnBnClickedBrowsevid)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMultisendDlg message handlers

BOOL CMultisendDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_ilContacts.Create(IDR_CONTACTS,16,1,RGB(255,0,255));
	m_cList.SetImageList(&m_ilContacts,LVSIL_SMALL);

	m_cList.InsertColumn(0,"Name",LVCFMT_LEFT,100,0);
	m_cList.InsertColumn(1,"Telephone",LVCFMT_LEFT,90,1);
	m_cList.InsertColumn(2,"e-mail",LVCFMT_LEFT,120,1);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMultisendDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMultisendDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMultisendDlg::OnRefresh() 
{
	BeginWaitCursor();
	SetDlgItemText(IDS_STATUS,"Retrieving contacts...");
	EmptyContactList();

	UpdateData();

	CCopiagenda ca;
	m_pmsoAddressBook = ca.RetrieveContacts(m_csUser,m_csPassword);

	if(!m_pmsoAddressBook)
	{
		SetDlgItemText(IDS_STATUS,"");
		return;
	}

	CStringArray* psaContact;
	CString csKey;
	for(POSITION pos=m_pmsoAddressBook->GetStartPosition();pos;)
	{
		m_pmsoAddressBook->GetNextAssoc(pos,csKey,(CObject*&)psaContact);

		int nItemReal;
		nItemReal=m_cList.InsertItem(-1,psaContact->GetAt(3),0);

		m_cList.SetItemText(nItemReal,1,psaContact->GetAt(11));
		m_cList.SetItemText(nItemReal,2,psaContact->GetAt(8));
	}

	/*CString csName = "xxxx";
	CStringArray* psaContacto = ca.SearchByName(csName, m_pmsoAddressBook);*/
	EndWaitCursor();
	SetDlgItemText(IDS_STATUS,"");
}

void CMultisendDlg::EmptyContactList()
{
	m_cList.DeleteAllItems();
	if(!m_pmsoAddressBook)
		return;

	CStringArray* psaContact;
	for(POSITION pos=m_pmsoAddressBook->GetStartPosition();pos;)
	{
		CString csKey;
		m_pmsoAddressBook->GetNextAssoc(pos,csKey,(CObject*&)psaContact);
		m_pmsoAddressBook->RemoveKey(csKey);

		delete psaContact;
	}

	delete m_pmsoAddressBook;
	m_pmsoAddressBook = NULL;
}

void CMultisendDlg::OnDestroy() 
{
	EmptyContactList();

	CDialog::OnDestroy();
}

bool CMultisendDlg::SendSMSMessage(CString csDestination)
{
	CSMSSender smss;
	CString csData=smss.SendMessage(m_csUser,m_csPassword,csDestination,m_csMessage);
	if(csData=="OK")
		return true;

	return false;
}

bool CMultisendDlg::SendMMSMessage(CString csDestination)
{
	CMMSSender mmss;
	mmss.Login(m_csUser,m_csPassword);

	if(!m_csPathImg.IsEmpty())
	{
		SetDlgItemText(IDS_STATUS,"Inserting image...");
		mmss.InsertImage(m_csPathImg);
	}
	if(!m_csPathSnd.IsEmpty())
	{
		SetDlgItemText(IDS_STATUS,"Inserting audio...");
		mmss.InsertAudio(m_csPathSnd);
	}
	if(!m_csPathVid.IsEmpty())
	{
		SetDlgItemText(IDS_STATUS,"Inserting v�deo...");
		mmss.InsertVideo(m_csPathVid);
	}

	SetDlgItemText(IDS_STATUS,"Sending MMS message...");
	bool bSent=mmss.SendMessage(m_csSubject, csDestination, m_csMessage);
	mmss.Logout();

	return bSent;
}

bool CMultisendDlg::SendAnyMessage(CString csDestination)
{
	int nPosAt=csDestination.Find("@");
	if(nPosAt!=-1)
		return SendMMSMessage(csDestination);

	if( (!m_csPathImg.IsEmpty()) || (!m_csPathSnd.IsEmpty()) || (!m_csPathVid.IsEmpty()) )
		return SendMMSMessage(csDestination);

	return SendSMSMessage(csDestination);
}

void CMultisendDlg::OnSend() 
{
	BeginWaitCursor();

	UpdateData();

	if(!m_csDestination.IsEmpty())
	{
		CString csStatus;
		csStatus.Format("Sending message to %s...",m_csDestination);
		SetDlgItemText(IDS_STATUS,csStatus);
		bool bSent=SendAnyMessage(m_csDestination);
		if(bSent)
		{
			CString csMsg;
			csMsg.Format("Message sent to %s",m_csDestination);
			AfxMessageBox(csMsg,MB_ICONINFORMATION);
		}
		else
		{
			CString csMsg;
			csMsg.Format("Messaje not sent to %s",m_csDestination);
			AfxMessageBox(csMsg,MB_ICONSTOP);
		}
		SetDlgItemText(IDS_STATUS,"");
	}
	else
	{
		CString csStatus;
		POSITION pos=m_cList.GetFirstSelectedItemPosition();
		while(pos)
		{
			int nItem=m_cList.GetNextSelectedItem(pos);
			CString csItem=m_cList.GetItemText(nItem,0);

			CStringArray* psaContact;
			m_pmsoAddressBook->Lookup(csItem,(CObject*&)psaContact);

			CString csTelephone=psaContact->GetAt(11);
			CString csEMail=psaContact->GetAt(8);

			CString csPreferredContact=csTelephone;
			if(csTelephone.IsEmpty())
				csPreferredContact=csEMail;

			if( (!csTelephone.IsEmpty()) && (!csEMail.IsEmpty()) )
			{
				CSelectDlg sdlg;
				if(!csTelephone.IsEmpty())
					sdlg.m_bTelephone=true;
				if(!csEMail.IsEmpty())
					sdlg.m_bEmail=true;
				sdlg.DoModal();
				CString csFavourite=sdlg.m_csOption;
				if(csFavourite=="e-mail")
					csPreferredContact=csEMail;
				else
					csPreferredContact=csTelephone;
			}

			if(!csPreferredContact.IsEmpty())
			{
				csStatus.Format("Sending message to %s (%s)...",psaContact->GetAt(3),csPreferredContact);
				SetDlgItemText(IDS_STATUS,csStatus);
				bool bSent=SendAnyMessage(csPreferredContact);
				if(bSent)
				{
					CString csMsg;
					csMsg.Format("Message sent to %s (%s)",psaContact->GetAt(3),csPreferredContact);
					AfxMessageBox(csMsg,MB_ICONINFORMATION);
				}
				else
				{
					CString csMsg;
					csMsg.Format("Message not sent to %s (%s)",psaContact->GetAt(3),csPreferredContact);
					AfxMessageBox(csMsg,MB_ICONSTOP);
				}
			}
			SetDlgItemText(IDS_STATUS,"");

		}
	}

	EndWaitCursor();
}

void CMultisendDlg::OnBnClickedBrowseimg()
{
	CString csMask=_T("Image files (*.jpg;*.jpeg;*.bmp;*.gif;*.png) | *.jpg;*.jpeg;*.bmp;*.gif;*.png||");
	CFileDialog fdlg(TRUE,_T("jpg;jpeg;bmp;gif;png"),_T("*.jpg;*.jpeg;*.bmp;*.gif;*.png"),0,csMask,NULL);
	UINT nRes=fdlg.DoModal();
	if(nRes==IDOK)
	{
		SetDlgItemText(IDC_PATHIMG,fdlg.GetPathName());
	}
}

void CMultisendDlg::OnBnClickedBrowsesnd()
{
	CString csMask=_T("Audio files (*.mid;*.wav;*.mp3) | *.mid;*.wav;*.mp3||");
	CFileDialog fdlg(TRUE,_T("mid;wav;mp3"),_T("*.mid;*.wav;*.mp3"),0,csMask,NULL);
	UINT nRes=fdlg.DoModal();
	if(nRes==IDOK)
	{
		SetDlgItemText(IDC_PATHSND,fdlg.GetPathName());
	}
}

void CMultisendDlg::OnBnClickedBrowsevid()
{

	CString csMask=_T("Video files (*.avi;*.asf;*.mpg;*.mpeg;*.wmv) | *.avi;*.asf;*.mpg;*.mpeg;*.wmv||");
	CFileDialog fdlg(TRUE,_T("avi;asf;mpg;mpeg;wmv"),_T("*.avi;*.asf;*.mpg;*.mpeg;*.wmv"),0,csMask,NULL);
	UINT nRes=fdlg.DoModal();
	if(nRes==IDOK)
	{
		SetDlgItemText(IDC_PATHVID,fdlg.GetPathName());
	}
}
