// MultisendDlg.h : header file
//

#if !defined(AFX_MULTISENDDLG_H__1105CB1F_5C4E_46AA_A795_2B8E1B0CD32B__INCLUDED_)
#define AFX_MULTISENDDLG_H__1105CB1F_5C4E_46AA_A795_2B8E1B0CD32B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMultisendDlg dialog

class CMultisendDlg : public CDialog
{
// Construction
public:
	CMultisendDlg(CWnd* pParent = NULL);	// standard constructor

	void EmptyContactList();

	bool SendMMSMessage(CString csDestination);
	bool SendSMSMessage(CString csDestination);
	bool SendAnyMessage(CString csDestination);

// Dialog Data
	//{{AFX_DATA(CMultisendDlg)
	enum { IDD = IDD_MULTISEND_DIALOG };
	CListCtrl	m_cList;
	CString	m_csUser;
	CString	m_csPassword;
	CString	m_csMessage;
	CString	m_csDestination;
	//}}AFX_DATA

	CMapStringToOb* m_pmsoAddressBook;

	CImageList	m_ilContacts;

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMultisendDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMultisendDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnRefresh();
	afx_msg void OnDestroy();
	afx_msg void OnSend();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	CString m_csSubject;
	CString m_csPathImg;
	CString m_csPathSnd;
	CString m_csPathVid;
	afx_msg void OnBnClickedBrowseimg();
	afx_msg void OnBnClickedBrowsesnd();
	afx_msg void OnBnClickedBrowsevid();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MULTISENDDLG_H__1105CB1F_5C4E_46AA_A795_2B8E1B0CD32B__INCLUDED_)
