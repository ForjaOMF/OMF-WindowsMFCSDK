// SelectDlg.cpp: archivo de implementaci�n
//

#include "stdafx.h"
#include "Multisend.h"
#include "SelectDlg.h"


// Cuadro de di�logo de CSelectDlg

IMPLEMENT_DYNAMIC(CSelectDlg, CDialog)
CSelectDlg::CSelectDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSelectDlg::IDD, pParent)
	, m_csOption(_T(""))
{
	m_bTelephone=false;
	m_bEmail=false;
}

CSelectDlg::~CSelectDlg()
{
}

void CSelectDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_CBString(pDX, IDC_OPTIONS, m_csOption);
	DDX_Control(pDX, IDC_OPTIONS, m_cOptions);
}


BEGIN_MESSAGE_MAP(CSelectDlg, CDialog)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
END_MESSAGE_MAP()


// Controladores de mensajes de CSelectDlg

BOOL CSelectDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	if(m_bTelephone)
        m_cOptions.AddString("Telephone");

	if(m_bEmail)
        m_cOptions.AddString("e-mail");

	m_cOptions.SetCurSel(0);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPCI�N: las p�ginas de propiedades OCX deben devolver FALSE
}

void CSelectDlg::OnBnClickedOk()
{
	UpdateData();

	OnOK();
}
