// SIPTestDlg.cpp: archivo de implementaci�n
//

#include "stdafx.h"
#include "SIPTest.h"
#include "SIPTestDlg.h"

#include "VideoCallReceiver.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// Cuadro de di�logo de CSIPTestDlg




CSIPTestDlg::CSIPTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSIPTestDlg::IDD, pParent)
	, m_csPassword(_T("olopas"))
	, m_csLogin(_T("686013749"))
	, m_csLocalIP(_T(""))
	, m_csPath(_T("c:\\cosas\\VideoLlamada"))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_pReceiver = NULL;
}

void CSIPTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_PASSWORD, m_csPassword);
	DDX_Text(pDX, IDC_LOGIN, m_csLogin);
	DDX_Text(pDX, IDC_LOCALIP, m_csLocalIP);
	DDX_Text(pDX, IDC_PATH, m_csPath);
	DDX_Control(pDX, IDC_LLAMADAS, m_cLlamadas);
}

BEGIN_MESSAGE_MAP(CSIPTestDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_REGISTER, &CSIPTestDlg::OnBnClickedRegister)
	ON_BN_CLICKED(IDC_UNREGISTER, &CSIPTestDlg::OnBnClickedUnregister)
	ON_WM_DESTROY()
END_MESSAGE_MAP()


// Controladores de mensaje de CSIPTestDlg

BOOL CSIPTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Establecer el icono para este cuadro de di�logo. El marco de trabajo realiza esta operaci�n
	//  autom�ticamente cuando la ventana principal de la aplicaci�n no es un cuadro de di�logo
	SetIcon(m_hIcon, TRUE);			// Establecer icono grande
	SetIcon(m_hIcon, FALSE);		// Establecer icono peque�o

	m_cLlamadas.InsertColumn(0,"Hora",LVCFMT_LEFT,120,0);
	m_cLlamadas.InsertColumn(1,"Llamante",LVCFMT_LEFT,80,1);

	return TRUE;  // Devuelve TRUE  a menos que establezca el foco en un control
}

// Si agrega un bot�n Minimizar al cuadro de di�logo, necesitar� el siguiente c�digo
//  para dibujar el icono. Para aplicaciones MFC que utilicen el modelo de documentos y vistas,
//  esta operaci�n la realiza autom�ticamente el marco de trabajo.

void CSIPTestDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Contexto de dispositivo para dibujo

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Centrar icono en el rect�ngulo de cliente
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Dibujar el icono
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// El sistema llama a esta funci�n para obtener el cursor que se muestra mientras el usuario arrastra
//  la ventana minimizada.
HCURSOR CSIPTestDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CSIPTestDlg::OnBnClickedRegister()
{
	UpdateData();

	if(m_pReceiver)
	{
		m_pReceiver->Unregister();
		delete m_pReceiver;
		m_pReceiver=NULL;
	}

	m_pReceiver = new CVideoCallReceiver(m_csLogin, m_csPassword, m_csLocalIP, m_csPath, DWORD(this));
	m_pReceiver->SetStartCallCB(LlamadaIniciada);
	m_pReceiver->SetEndCallCB(LlamadaFinalizada);
	m_pReceiver->RegisterAttempt();
}

void CSIPTestDlg::OnBnClickedUnregister()
{
	if(m_pReceiver)
	{
		m_pReceiver->Unregister();
		delete m_pReceiver;
		m_pReceiver=NULL;
	}
}

void CSIPTestDlg::OnDestroy()
{
	CDialog::OnDestroy();

	if(m_pReceiver)
	{
		m_pReceiver->Unregister();
		delete m_pReceiver;
		m_pReceiver=NULL;
	}
}

void CSIPTestDlg::InsertaLlamada(CVideoCall* pVCall)
{
	int nItemReal;
	nItemReal=m_cLlamadas.InsertItem(-1,pVCall->GetStartTime(),0);
	m_cLlamadas.SetItemText(nItemReal,1,pVCall->GetFrom());
	m_cLlamadas.SetItemData(nItemReal,(DWORD)pVCall);
}

void CSIPTestDlg::LlamadaIniciada(DWORD dwCookie, CVideoCall* pVCall)
{
	CSIPTestDlg* pThis=(CSIPTestDlg*)dwCookie;
	if(pThis)
	{
		pThis->InsertaLlamada(pVCall);
	}
}

void CSIPTestDlg::BorraLlamada(CVideoCall* pVCall)
{
	int nCount=m_cLlamadas.GetItemCount();
	for(int i=0;i<nCount;i++)
	{
		CVideoCall* pVC=(CVideoCall*)m_cLlamadas.GetItemData(i);
		if(pVC==pVCall)
			m_cLlamadas.DeleteItem(i);
	}
}

void CSIPTestDlg::LlamadaFinalizada(DWORD dwCookie, CVideoCall* pVCall)
{
	CSIPTestDlg* pThis=(CSIPTestDlg*)dwCookie;
	if(pThis)
	{
		pThis->BorraLlamada(pVCall);
	}
}
