#if !defined(AFX_SIPSOCKET_H__95AC0C90_DDAF_43D6_88A4_73E9998B5EE5__INCLUDED_)
#define AFXSIPSOCKET_H__95AC0C90_DDAF_43D6_88A4_73E9998B5EE5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SIPSocket.h : header file
//

#include <afxsock.h>

#define FSOCK_CONNECT	1
#define FSOCK_RECEIVE	2
#define FSOCK_ACCEPT	3
#define FSOCK_CLOSE		4

typedef void (* tagCallbackFn)(DWORD dwCookie,UINT nCode,char* pBufData,DWORD dwLenData,int nErrorCode);

/////////////////////////////////////////////////////////////////////////////
// CSIPSocket command target

class CSIPSocket : public CAsyncSocket
{
// Attributes
public:

// Operations
public:
	CSIPSocket();
	CSIPSocket(tagCallbackFn pCallbackFunction,DWORD dwCookie);
	virtual ~CSIPSocket();

	void SetCookie(DWORD dwCookie){m_dwCookie=dwCookie;};
	void SetCallbackFn(tagCallbackFn pCallbackFunction){m_pCallbackFunction=pCallbackFunction;};

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSIPSocket)
	public:
	virtual void OnReceive(int nErrorCode);
	virtual void OnConnect(int nErrorCode);
	virtual void OnAccept(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CSIPSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
	DWORD			m_dwCookie;
	tagCallbackFn	m_pCallbackFunction;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIPSOCKET_H__95AC0C90_DDAF_43D6_88A4_73E9998B5EE5__INCLUDED_)
