// SIPTestDlg.h: archivo de encabezado
//

#pragma once
#include "afxcmn.h"

class CVideoCallReceiver;
class CVideoCall;

// Cuadro de di�logo de CSIPTestDlg
class CSIPTestDlg : public CDialog
{
// Construcci�n
public:
	CSIPTestDlg(CWnd* pParent = NULL);	// Constructor est�ndar

	void InsertaLlamada(CVideoCall* pVCall);
	void BorraLlamada(CVideoCall* pVCall);

	static void LlamadaIniciada(DWORD dwCookie, CVideoCall* pVCall);
	static void LlamadaFinalizada(DWORD dwCookie, CVideoCall* pVCall);

// Datos del cuadro de di�logo
	enum { IDD = IDD_SIPTEST_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// Compatibilidad con DDX/DDV


// Implementaci�n
protected:
	HICON m_hIcon;

	CVideoCallReceiver* m_pReceiver;

	// Funciones de asignaci�n de mensajes generadas
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedRegister();
	CString m_csPassword;
	CString m_csLogin;
	afx_msg void OnBnClickedUnregister();
	afx_msg void OnDestroy();
	CString m_csLocalIP;
	CString m_csPath;
	CListCtrl m_cLlamadas;
};
