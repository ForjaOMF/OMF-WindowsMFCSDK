// VideoCallReceiver.cpp: archivo de implementaci�n
//

#include "stdafx.h"
#include "VideoCallReceiver.h"

#include "SIPSocket.h"
#include "Frame263.h"
#include "WriteAvi.h"
#include "MD5Checksum.h"
#include "decoder\tmndec.h"


CVideoCallReceiver::CVideoCallReceiver(CString csLogin, CString csPassword, CString csLocalIP, CString csPath)
{
	m_csLogin=csLogin;
	m_csPassword=csPassword;
	m_csLocalIP=csLocalIP;
	m_csPath=csPath;

	m_bRegistered=false;

	m_pSocketAudio=NULL;
	m_pSocketAudioCtrl=NULL;
	m_pSocketVideo=NULL;
	m_pSocketVideoCtrl=NULL;

	bool bRes;
	m_pSocket=new CSIPSocket(OnEvent,(DWORD)this);
	if(csLocalIP.IsEmpty())
	{
		bRes=m_pSocket->Create(5061,SOCK_DGRAM,FD_READ|FD_WRITE);

		CString csHost;
		UINT nPort;
		m_pSocket->GetSockNameEx(csHost, nPort);

		hostent* pRemoteHost = gethostbyname(csHost.GetBuffer());
		if(pRemoteHost)
		{
			in_addr addr;
			addr.s_addr = *(u_long *) pRemoteHost->h_addr_list[0];
			m_csLocalIP=inet_ntoa(addr);
		}
	}
	else
	{
		bRes=m_pSocket->Create(5061,SOCK_DGRAM,FD_READ|FD_WRITE,m_csLocalIP);
	}
}

CVideoCallReceiver::~CVideoCallReceiver()
{
	if(m_pSocketAudio)
	{
		m_pSocketAudio->Close();
		delete m_pSocketAudio;
		m_pSocketAudio=NULL;
	}
	if(m_pSocketAudioCtrl)
	{
		m_pSocketAudioCtrl->Close();
		delete m_pSocketAudioCtrl;
		m_pSocketAudioCtrl=NULL;
	}

	if(m_pSocketVideo)
	{
		m_pSocketVideo->Close();
		delete m_pSocketVideo;
		m_pSocketVideo=NULL;
	}
	if(m_pSocketVideoCtrl)
	{
		m_pSocketVideoCtrl->Close();
		delete m_pSocketVideoCtrl;
		m_pSocketVideoCtrl=NULL;
	}

	if(m_pSocket)
	{
		m_pSocket->Close();
		delete m_pSocket;
		m_pSocket=NULL;
	}
}

void CVideoCallReceiver::OnReceiveData(char* pBufData,DWORD dwLenData,int nErrorCode)
{
	char strData[65000];
	memset(strData,0,65000);
	memcpy(strData,pBufData,dwLenData);

	CString csData=strData;
	int nPos401=csData.Find("401 Unauthorized");
	if (nPos401!=-1)
		ReRegister(csData);

	int nPos200=csData.Find("200 OK");
	if (nPos200!=-1)
	{
		if(!m_bRegistered)
			AfxMessageBox("Conectado");
		m_bRegistered = true;
		// Registrado!!
	}

	if(csData.Left(6)=="INVITE")
	{
		AcceptInvitation(csData);
	}
	else if(csData.Left(3)=="ACK")
	{
		SendMultimediaData(csData);
	}
	else if(csData.Left(3)=="BYE")
	{
		AckBye(csData);
		ExportAudio();
		ExportVideo();
	}
}


void CVideoCallReceiver::OnEvent(DWORD dwCookie,UINT nCode,char* pBufData,DWORD dwLenData,int nErrorCode)
{
	CVideoCallReceiver* pThis=(CVideoCallReceiver*)dwCookie;
	if(pThis)
	{
		switch(nCode)
		{
			case FSOCK_RECEIVE:
				pThis->OnReceiveData(pBufData,dwLenData,nErrorCode);
				break;
			case FSOCK_ACCEPT:
				break;
			case FSOCK_CLOSE:
				//pThis->OnCloseSocket(nErrorCode);
				break;
		}
	}
}


void CVideoCallReceiver::RegisterAttempt()
{
	CString csRegister1;
	csRegister1.Format(
		"REGISTER sip:195.76.180.160 SIP/2.0\r\n"
		"Via: SIP/2.0/UDP %s:5061;rport;branch=z9hG4bK21898\r\n"
		"From: <sip:%s@movistar.es>;tag=13939\r\n"
		"To: <sip:%s@movistar.es>\r\n"
		"Call-ID: 9979@%s\r\n"
		"CSeq: 1 REGISTER\r\n"
		"Contact: <sip:%s@%s:5061>\r\n"
		"Max-Forwards: 70\r\n"
		"Expires: 3600\r\n"
		"Allow-Events: presence\r\n"
		"Event: registration\r\n"
		"User-Agent: Intellivic/PC\r\n"
		"Allow: ACK, BYE, CANCEL, INVITE, MESSAGE, OPTIONS, REFER, PRACK\r\n"
		"Content-Length: 0\r\n\r\n", m_csLocalIP, m_csLogin, m_csLogin, m_csLocalIP, m_csLogin, m_csLocalIP);

	if(m_pSocket)
		m_pSocket->SendTo((void*)csRegister1.GetBuffer(0),csRegister1.GetLength(), 5060, "195.76.180.160");
}

void CVideoCallReceiver::AcceptInvitation(CString csInvitation)
{
	int nPosCallId=csInvitation.Find("Call-ID: ");
	if(nPosCallId!=-1)
	{
		int nPosCallIdEnd=csInvitation.Find("\r\n",nPosCallId+10);
		if(nPosCallIdEnd!=-1)
			m_csCallId=csInvitation.Mid(nPosCallId+9,nPosCallIdEnd-nPosCallId-9);
		else
			m_csCallId=csInvitation.Left(nPosCallId+9);
	}

	COleDateTime odtNow=COleDateTime::GetCurrentTime();
	m_csStartTime=odtNow.Format("%Y%m%d%H%M%S");
	nPosCallId=csInvitation.Find("From: <sip:");
	if(nPosCallId!=-1)
	{
		int nPosCallIdEnd=csInvitation.Find("@",nPosCallId+11);
		if(nPosCallIdEnd!=-1)
			m_csFrom=csInvitation.Mid(nPosCallId+11,nPosCallIdEnd-nPosCallId-11);
		else
			m_csFrom=csInvitation.Left(nPosCallId+11);
	}
	// S�lo hasta que est� la lista de llamadas, luego se usar�n los dos campos por separado
	// y m_csCallId se dejar� para indexar la lista.
	//m_csCallId.Format("%s%s",m_csStartTime,m_csFrom);

	int nPosBranch=csInvitation.Find("branch=");
	if(nPosBranch!=-1)
	{
		int nPosBranchEnd=csInvitation.Find("\r\n",nPosBranch+8);
		if(nPosBranchEnd!=-1)
			m_csBranch=csInvitation.Mid(nPosBranch+7,nPosBranchEnd-nPosBranch-7);
		else
			m_csBranch=csInvitation.Left(nPosBranch+7);
	}

	int nPosTag=csInvitation.Find("From: <sip:anonymous@movistar.es>;tag=");
	if(nPosTag!=-1)
	{
		int nPosTagEnd=csInvitation.Find("\r\n",nPosTag+39);
		if(nPosTagEnd!=-1)
			m_csFromTag=csInvitation.Mid(nPosTag+38,nPosTagEnd-nPosTag-38);
		else
			m_csFromTag=csInvitation.Left(nPosTag+38);
	}

	CString csTrying;
	csTrying.Format(
		"SIP/2.0 100 Trying\r\n"
		"Via: SIP/2.0/UDP 195.76.180.160:5060;branch=%s\r\n"
		"From: <sip:anonymous@movistar.es>;tag=%s\r\n"
		"To: <sip:%s@movistar.es:5060;user=phone>\r\n"
		"Call-Id: %s\r\n"
		"CSeq: 1 INVITE\r\n"
		"Content-Length: 0\r\n\r\n", m_csBranch, m_csFromTag, m_csLogin, m_csCallId);
	if(m_pSocket)
		m_pSocket->SendTo((void*)csTrying.GetBuffer(0),csTrying.GetLength(), 5060, "195.76.180.160");

	CString csRinging;
	csRinging.Format(
		"SIP/2.0 180 Ringing\r\n"
		"Via: SIP/2.0/UDP 195.76.180.160:5060;branch=%s\r\n"
		"From: <sip:anonymous@movistar.es>;tag=%s\r\n"
		"To: <sip:%s@movistar.es:5060;user=phone>\r\n"
		"Call-Id: %s\r\n"
		"CSeq: 1 INVITE\r\n"
		"Contact: <sip:%s@%s:5061>\r\n"
		"Content-Length: 0\r\n\r\n", m_csBranch, m_csFromTag, m_csLogin, m_csCallId, m_csLogin, m_csLocalIP);
	if(m_pSocket)
		m_pSocket->SendTo((void*)csRinging.GetBuffer(0),csRinging.GetLength(), 5060, "195.76.180.160");

	CString csContent;
	csContent.Format(
		"v=0\r\n"
		"o=- 26069 29246 IN IP4 %s\r\n"
		"s=-\r\n"
		"c=IN IP4 %s\r\n"
		"t=0 0\r\n"
		"m=audio 23010 RTP/AVP 101 99 0 8 104\r\n"
		"a=rtpmap:101 speex/16000\r\n"
		"a=fmtp:101 vbr=on;mode=6\r\n"
		"a=rtpmap:99 speex/8000\r\n"
		"a=fmtp:99 vbr=on;mode=3\r\n"
		"a=rtpmap:0 PCMU/8000\r\n"
		"a=rtpmap:8 PCMA/8000\r\n"
		"a=rtpmap:104 telephone-event/8000\r\n"
		"a=fmtp:104 0-15\r\n"
		"m=video 23030 RTP/AVP 97 34\r\n"
		"a=rtpmap:97 MP4V-ES/90000\r\n"
		"a=fmtp:97 profile-level-id=1\r\n"
		"a=rtpmap:34 H263/90000\r\n"
		"a=fmtp:34 QCIF=2 SQCIF=2/MaxBR=560\r\n"
		,m_csLocalIP,m_csLocalIP);

	CString csSDP;
	csSDP.Format(
		"SIP/2.0 200 OK\r\n"
		"Via: SIP/2.0/UDP 195.76.180.160:5060;branch=%s\r\n"
		"From: <sip:anonymous@movistar.es>;tag=%s\r\n"
		"To: <sip:%s@movistar.es:5060;user=phone>;tag=9095\r\n"
		"Call-Id: %s\r\n"
		"CSeq: 1 INVITE\r\n"
		"Contact: <sip:%s@%s:5061>\r\n"
		"User-Agent: Intellivic/PC\r\n"
		"Supported: replaces\r\n"
		"Allow: ACK, BYE, CANCEL, INVITE, OPTIONS\r\n"
		"Content-Type: application/sdp\r\n"
		"Accept: application/sdp, application/media_control+xml, application/dtmf-relay\r\n"
		"Content-Length: %d\r\n\r\n%s", m_csBranch, m_csFromTag, m_csLogin, m_csCallId
			, m_csLogin, m_csLocalIP, csContent.GetLength(),csContent);
	if(m_pSocket)
		m_pSocket->SendTo((void*)csSDP.GetBuffer(0),csSDP.GetLength(), 5060, "195.76.180.160");
}

void CVideoCallReceiver::SendMultimediaData(CString csAckData)
{
	CString csPortAudio;
	int nPosAudio=csAckData.Find("m=audio");
	if(nPosAudio!=-1)
	{
		int nPosAudioEnd=csAckData.Find("RTP",nPosAudio+7);
		if(nPosAudioEnd!=-1)
		{
			csPortAudio=csAckData.Mid(nPosAudio+7,nPosAudioEnd-nPosAudio-7);
			csPortAudio.TrimLeft();
			csPortAudio.TrimRight();
		}
	}
	CString csPortVideo;
	int nPosVideo=csAckData.Find("m=video");
	if(nPosVideo!=-1)
	{
		int nPosVideoEnd=csAckData.Find("RTP",nPosVideo+7);
		if(nPosVideoEnd!=-1)
		{
			csPortVideo=csAckData.Mid(nPosVideo+7,nPosVideoEnd-nPosVideo-7);
			csPortVideo.TrimLeft();
			csPortVideo.TrimRight();
		}
	}

	if( (csPortAudio.IsEmpty()) || (csPortVideo.IsEmpty()) )
		return;

	m_nPortAudio=atoi(csPortAudio);
	m_nPortVideo=atoi(csPortVideo);

	bool bRes;

	m_pSocketAudio=new CSIPSocket(OnEventAudio,(DWORD)this);
	bRes=m_pSocketAudio->Create(23010,SOCK_DGRAM,FD_READ|FD_WRITE,m_csLocalIP);
	m_pSocketAudioCtrl=new CSIPSocket(OnEventAudioCtrl,(DWORD)this);
	bRes=m_pSocketAudioCtrl->Create(23011,SOCK_DGRAM,FD_READ|FD_WRITE,m_csLocalIP);

	m_pSocketVideo=new CSIPSocket(OnEventVideo,(DWORD)this);
	bRes=m_pSocketVideo->Create(23030,SOCK_DGRAM,FD_READ|FD_WRITE,m_csLocalIP);
	m_pSocketVideoCtrl=new CSIPSocket(OnEventVideoCtrl,(DWORD)this);
	bRes=m_pSocketVideoCtrl->Create(23031,SOCK_DGRAM,FD_READ|FD_WRITE,m_csLocalIP);

	// Audio Control
	BYTE pDataAudio[44]={0x80, 0xc9, 0x00, 0x01, 0x52, 0xb1, 0x9e, 0xd0,
						0x81, 0xca, 0x00, 0x06, 0x52, 0xb1, 0x9e, 0xd0,
						0x01, 0x0e, 0x46, 0x72, 0x61, 0x6e, 0x5f, 0x6d,
						0x40, 0x46, 0x72, 0x61, 0x6e, 0x5f, 0x6d, 0x31,
						0x00, 0x00, 0x00, 0x00, 0x81, 0xcb, 0x00, 0x01,
						0x52, 0xb1, 0x9e, 0xd0};
	if(m_pSocketAudioCtrl)
		m_pSocketAudioCtrl->SendTo(pDataAudio,44,m_nPortAudio+1,"195.76.180.160");

	// VideoControl
	BYTE pDataVideo[44]={0x80, 0xc9, 0x00, 0x01, 0x73, 0xaa, 0xdf, 0xe2,
						0x81, 0xca, 0x00, 0x06, 0x52, 0xb1, 0x9e, 0xd0,
						0x01, 0x0e, 0x46, 0x72, 0x61, 0x6e, 0x5f, 0x6d,
						0x40, 0x46, 0x72, 0x61, 0x6e, 0x5f, 0x6d, 0x31,
						0x00, 0x00, 0x00, 0x00, 0x81, 0xcb, 0x00, 0x01,
						0x73, 0xaa, 0xdf, 0xe2};
	if(m_pSocketVideoCtrl)
		m_pSocketVideoCtrl->SendTo(pDataVideo,44,m_nPortVideo+1,"195.76.180.160");

	// Audio
	BYTE pDataAudioData[12]={0x80, 0x80, 0x04, 0xae, 0xbd, 0xb7, 0xc1, 0x40,
							0x52, 0xb1, 0x9e, 0xd0};
	if(m_pSocketAudio)
		m_pSocketAudio->SendTo(pDataAudioData,12,m_nPortAudio,"195.76.180.160");

	// Video
	BYTE pDataVideoData[21]={0x80, 0x22, 0x8e, 0x9c, 0xef, 0xdb, 0xaf, 0x08,
							0x73, 0xaa, 0xdf, 0xe2, 0x00, 0x40, 0x00, 0x00,
							0x00, 0x80, 0x02, 0x08, 0x08};
	if(m_pSocketVideo)
		m_pSocketVideo->SendTo(pDataVideoData,21,m_nPortVideo,"195.76.180.160");
}

void CVideoCallReceiver::ReRegister(CString cs401)
{
	int nPosNonce=cs401.Find("nonce=\"");
	if(nPosNonce!=-1)
	{
		int nPosNonceEnd=cs401.Find("\"",nPosNonce+8);
		if(nPosNonceEnd!=-1)
			m_csNonce=cs401.Mid(nPosNonce+7,nPosNonceEnd-nPosNonce-7);
		else
			m_csNonce=cs401.Left(nPosNonce+7);
	}

	Register(3600);
}

void CVideoCallReceiver::Register(long lExpires)
{
	CMD5Checksum* pmd5=new CMD5Checksum();

	CString csLine1;
	csLine1.Format("%s:movistar.es:%s",m_csLogin,m_csPassword);
	CString csHA1=pmd5->GetMD5((BYTE*)csLine1.GetBuffer(0),csLine1.GetLength());
	
	CString csLine2="REGISTER:sip:195.76.180.160";
	CString csHA2=pmd5->GetMD5((BYTE*)csLine2.GetBuffer(0),csLine2.GetLength());

	CString csLine3;
	csLine3.Format("%s:%s:00000001:473:auth:%s",csHA1,m_csNonce,csHA2);
	CString csResponse=pmd5->GetMD5((BYTE*)csLine3.GetBuffer(0),csLine3.GetLength());

	CString csRegister2;
	csRegister2.Format(
		"REGISTER sip:195.76.180.160 SIP/2.0\r\n"
		"Via: SIP/2.0/UDP %s:5061;rport;branch=z9hG4bK23080\r\n"
		"From: <sip:%s@movistar.es>;tag=13939\r\n"
		"To: <sip:%s@movistar.es>\r\n"
		"Call-ID: 9979@%s\r\n"
		"CSeq: 2 REGISTER\r\n"
		"Contact: <sip:%s@%s:5061>\r\n"
		"Authorization: digest username=\"%s\", realm=\"movistar.es\", nonce=\"%s\", uri=\"sip:195.76.180.160\", response=\"%s\", algorithm=md5, cnonce=\"473\", qop=auth, nc=00000001\r\n"
		"Max-Forwards: 70\r\n"
		"Expires: %d\r\n"
		"Allow-Events: presence\r\n"
		"Event: registration\r\n"
		"User-Agent: Intellivic/PC\r\n"
		"Allow: ACK, BYE, CANCEL, INVITE, MESSAGE, OPTIONS, REFER, PRACK\r\n"
		"Content-Length: 0\r\n\r\n", m_csLocalIP, m_csLogin, m_csLogin, m_csLocalIP, m_csLogin, m_csLocalIP, m_csLogin, m_csNonce, csResponse, lExpires);

	if(m_pSocket)
		m_pSocket->SendTo((void*)csRegister2.GetBuffer(0),csRegister2.GetLength(), 5060, "195.76.180.160");
}

void CVideoCallReceiver::Echo(char* pBufData,DWORD dwLenData)
{
	if(m_pSocketAudio)
		m_pSocketAudio->SendTo(pBufData,dwLenData,m_nPortAudio,"195.76.180.160");
}

void CVideoCallReceiver::SaveAudioData(char* pBufData,DWORD dwLenData)
{
	CFile fl;
	BOOL bRes=fl.Open(m_csPath+"\\"+m_csCallId+".raw",CFile::modeWrite);
	if(!bRes)
		bRes=fl.Open(m_csPath+"\\"+m_csCallId+".raw",CFile::modeWrite|CFile::modeCreate);
	if(bRes)
	{
		fl.SeekToEnd();
		fl.Write(pBufData,dwLenData);
		fl.Close();
	}
}

void CVideoCallReceiver::OnEventAudio(DWORD dwCookie,UINT nCode,char* pBufData,DWORD dwLenData,int nErrorCode)
{
	if(nCode==FSOCK_RECEIVE)
	{
		CVideoCallReceiver* pDlg=(CVideoCallReceiver*)dwCookie;
		pDlg->Echo(pBufData,dwLenData);

		if(dwLenData>12)
		{
			BYTE* pRes=NULL;
			pRes = (BYTE*)malloc((dwLenData-12) * 2);
			pDlg->DecodeArray((BYTE*)&pBufData[12],dwLenData-12,pRes);
			pDlg->SaveAudioData((char*)pRes,(dwLenData-12)*2);
			free(pRes);
		}
	}
}

void CVideoCallReceiver::OnEventAudioCtrl(DWORD dwCookie,UINT nCode,char* pBufData,DWORD dwLenData,int nErrorCode)
{
	int i=0;
}

void CVideoCallReceiver::Mirror(char* pBufData,DWORD dwLenData)
{
	if(m_pSocketVideo)
		m_pSocketVideo->SendTo(pBufData,dwLenData,m_nPortVideo,"195.76.180.160");
}

void CVideoCallReceiver::SaveVideoData(char* pBufData,DWORD dwLenData)
{
	CFile fl;
	BOOL bRes=fl.Open(m_csPath+"\\"+m_csCallId+".263",CFile::modeWrite);
	if(!bRes)
		bRes=fl.Open(m_csPath+"\\"+m_csCallId+".263",CFile::modeWrite|CFile::modeCreate);
	if(bRes)
	{
		fl.SeekToEnd();
		fl.Write(pBufData,dwLenData);
		fl.Close();
	}
}

void CVideoCallReceiver::OnEventVideo(DWORD dwCookie,UINT nCode,char* pBufData,DWORD dwLenData,int nErrorCode)
{
	if(nCode==FSOCK_RECEIVE)
	{
		CVideoCallReceiver* pDlg=(CVideoCallReceiver*)dwCookie;
		pDlg->SaveVideoData(pBufData,dwLenData);

		pDlg->Mirror(pBufData,dwLenData);
	}
}

void CVideoCallReceiver::OnEventVideoCtrl(DWORD dwCookie,UINT nCode,char* pBufData,DWORD dwLenData,int nErrorCode)
{
	int i=0;
}

void CVideoCallReceiver::AckBye(CString csBye)
{
	// Audio Control
	BYTE pDataAudio[44]={0x80, 0xc9, 0x00, 0x01, 0x52, 0xb1, 0x9e, 0xd0,
						0x81, 0xca, 0x00, 0x06, 0x52, 0xb1, 0x9e, 0xd0,
						0x01, 0x0e, 0x46, 0x72, 0x61, 0x6e, 0x5f, 0x6d,
						0x40, 0x46, 0x72, 0x61, 0x6e, 0x5f, 0x6d, 0x31,
						0x00, 0x00, 0x00, 0x00, 0x81, 0xcb, 0x00, 0x01,
						0x52, 0xb1, 0x9e, 0xd0};
	if(m_pSocketAudioCtrl)
		m_pSocketAudioCtrl->SendTo(pDataAudio,44,m_nPortAudio+1,"195.76.180.160");

	// VideoControl
	BYTE pDataVideo[44]={0x80, 0xc9, 0x00, 0x01, 0x73, 0xaa, 0xdf, 0xe2,
						0x81, 0xca, 0x00, 0x06, 0x52, 0xb1, 0x9e, 0xd0,
						0x01, 0x0e, 0x46, 0x72, 0x61, 0x6e, 0x5f, 0x6d,
						0x40, 0x46, 0x72, 0x61, 0x6e, 0x5f, 0x6d, 0x31,
						0x00, 0x00, 0x00, 0x00, 0x81, 0xcb, 0x00, 0x01,
						0x73, 0xaa, 0xdf, 0xe2};
	if(m_pSocketVideoCtrl)
		m_pSocketVideoCtrl->SendTo(pDataVideo,44,m_nPortVideo+1,"195.76.180.160");

	int nPosBranch=csBye.Find("branch=");
	if(nPosBranch!=-1)
	{
		int nPosBranchEnd=csBye.Find("\r\n",nPosBranch+8);
		if(nPosBranchEnd!=-1)
			m_csBranch=csBye.Mid(nPosBranch+7,nPosBranchEnd-nPosBranch-7);
		else
			m_csBranch=csBye.Left(nPosBranch+7);
	}

	CString csTrying;
	csTrying.Format(
		"SIP/2.0 200 OK\r\n"
		"Via: SIP/2.0/UDP 195.76.180.160:5060;branch=%s\r\n"
		"From: <sip:anonymous@movistar.es>;tag=%s\r\n"
		"To: <sip:%s@movistar.es:5060;user=phone>;tag=9095\r\n"
		"Call-Id: %s\r\n"
		"CSeq: 2 Bye\r\n"
		"Content-Length: 0\r\n\r\n", m_csBranch, m_csFromTag, m_csLogin, m_csCallId);
	if(m_pSocket)
		m_pSocket->SendTo((void*)csTrying.GetBuffer(0),csTrying.GetLength(), 5060, "195.76.180.160");

	if(m_pSocketAudio)
	{
		m_pSocketAudio->Close();
		delete m_pSocketAudio;
		m_pSocketAudio=NULL;
	}

	if(m_pSocketAudioCtrl)
	{
		m_pSocketAudioCtrl->Close();
		delete m_pSocketAudioCtrl;
		m_pSocketAudioCtrl=NULL;
	}

	if(m_pSocketVideo)
	{
		m_pSocketVideo->Close();
		delete m_pSocketVideo;
		m_pSocketVideo=NULL;
	}

	if(m_pSocketVideoCtrl)
	{
		m_pSocketVideoCtrl->Close();
		delete m_pSocketVideoCtrl;
		m_pSocketVideoCtrl=NULL;
	}

	Register(3600);
}

void CVideoCallReceiver::Unregister()
{
	Register(0);
}

void CVideoCallReceiver::DecodeArray(BYTE* pData, DWORD dwLen, BYTE* pRes)
{
    short* pmuLawToPcmMap = (short*)malloc(256*sizeof(short));
    for (short i = 0; i < 256; i++)
        pmuLawToPcmMap[i] = DecodeByte((BYTE)i);

	for (int i = 0; i < dwLen; i++)
	{
		//First byte is the less significant byte
		pRes[2 * i] = (BYTE)(pmuLawToPcmMap[pData[i]] & 0xff);
		//Second byte is the more significant byte
		pRes[2 * i + 1] = (BYTE)(pmuLawToPcmMap[pData[i]] >> 8);
	}
}

short CVideoCallReceiver::DecodeByte(BYTE mulaw)
{
    //Flip all the bits
    mulaw = (BYTE)~mulaw;

    //Pull out the value of the sign bit
    short sign = mulaw & 0x80;
    //Pull out and shift over the value of the exponent
    short exponent = (mulaw & 0x70) >> 4;
    //Pull out the four bits of data
    short data = mulaw & 0x0f;

    //Add on the implicit fifth bit (we know 
    //the four data bits followed a one bit)
    data |= 0x10;
    /* Add a 1 to the end of the data by 
    * shifting over and adding one. Why?
    * Mu-law is not a one-to-one function. 
    * There is a range of values that all
    * map to the same mu-law byte. 
    * Adding a one to the end essentially adds a
    * "half byte", which means that 
    * the decoding will return the value in the
    * middle of that range. Otherwise, the mu-law
    * decoding would always be
    * less than the original data. */
    data <<= 1;
    data += 1;
    /* Shift the five bits to where they need
    * to be: left (exponent + 2) places
    * Why (exponent + 2) ?
    * 1 2 3 4 5 6 7 8 9 A B C D E F G
    * . 7 6 5 4 3 2 1 0 . . . . . . . <-- starting bit (based on exponent)
    * . . . . . . . . . . 1 x x x x 1 <-- our data
    * We need to move the one under the value of the exponent,
    * which means it must move (exponent + 2) times
    */
    data <<= exponent + 2;
    //Remember, we added to the original,
    //so we need to subtract from the final
    data -= 0x84;
    //If the sign bit is 0, the number 
    //is positive. Otherwise, negative.
    return (short)(sign == 0 ? data : -data);
}

void CVideoCallReceiver::ExportAudio()
{
	CString csFile=m_csPath+"\\"+m_csCallId+".raw";

	CFile fl;
	BOOL bRes=fl.Open(csFile,CFile::modeRead);
	if(bRes)
	{
		size_t flsize=fl.GetLength();
		BYTE* pBuffer=(BYTE*)malloc(flsize);
		fl.Read(pBuffer,flsize);
		fl.Close();

		CString csFileSave=m_csPath+"\\"+m_csCallId+".wav";

		CFile fl2;
		BOOL bRes2=fl2.Open(csFileSave,CFile::modeWrite|CFile::modeCreate);
		if(bRes2)
		{
			BYTE strHead[]={0x52, 0x49, 0x46, 0x46, 0xA4, 0x95, 0x08, 0x00,
							0x57, 0x41, 0x56, 0x45, 0x66, 0x6D, 0x74, 0x20,
							0x10, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00,
							0x40, 0x1F, 0x00, 0x00, 0x80, 0x3E, 0x00, 0x00,
							0x02, 0x00, 0x10, 0x00, 0x64, 0x61, 0x74, 0x61};
			fl2.Write(strHead,40);
			fl2.Write(&flsize,4);
			fl2.Write(pBuffer,flsize);

			fl2.Close();

			try { CFile::Remove(csFile); }
			catch(CFileException) {}
		}
	}
}

void CVideoCallReceiver::InsertFrame(CObList& olFrames, CFrame263* pFrame, DWORD& dwPreviousFrame)
{
	if( (pFrame->GetFrameNumber()>dwPreviousFrame) || (dwPreviousFrame==0) )
	{
		pFrame->SetTimerValue( (pFrame->GetFrameNumber()-dwPreviousFrame) * 30 );
		olFrames.AddTail(pFrame);
		dwPreviousFrame=pFrame->GetFrameNumber();
	}
	else if(dwPreviousFrame!=0)
	{
		pFrame->SetTimerValue( pFrame->GetFrameNumber() * 30 );
		olFrames.AddTail(pFrame);
		dwPreviousFrame=pFrame->GetFrameNumber();
	}
	else
		delete pFrame;
}

void CVideoCallReceiver::RenderFrame(BYTE* pDecodedFrame, CFrame263* pFrame, DWORD dwFileSize, BYTE* pVideoBuffer)
{
	if(pFrame->GetDecoded())
	{
		memcpy(pDecodedFrame,pFrame->GetDecoded(),pFrame->GetDecodedSize());
	}
	else
	{
		DWORD dwSize=dwFileSize-(pFrame->GetBuffer()-pVideoBuffer);
		int nRet;
		pFrame->GetBuffer()[0]=0;
		nRet=DecompressFrame(pFrame->GetBuffer(),pFrame->GetBufferSize(),pDecodedFrame,80000,0);

		pFrame->SetDecoded(pDecodedFrame,80000);
	}
}

void CVideoCallReceiver::ExportVideo()
{
	CString csFile=m_csPath+"\\"+m_csCallId+".263";

	CFile fl;
	size_t flsize=0;
	BYTE* pBuffer=NULL;
	BOOL bRes=fl.Open(csFile,CFile::modeRead);
	if(!bRes)
		return;

	CObList olFrames;

	flsize=fl.GetLength();
	pBuffer=(BYTE*)malloc(flsize);
	fl.Read(pBuffer,flsize);
	fl.Close();

	DWORD dwValue;
	DWORD dwPosFirst=0;

	if(!flsize)
		return;

	DWORD dwPreviousFrame=0;
	DWORD dwDuration=0;
	for(DWORD dwPos=0;dwPos<flsize-3;dwPos++)
	{
		dwValue=pBuffer[dwPos];
		dwValue<<=8;
		dwValue+=pBuffer[dwPos+1];
		dwValue<<=8;
		dwValue+=pBuffer[dwPos+2];
		dwValue>>=2;

		if(dwValue==0x20)
		{
			if(!dwPosFirst)
				dwPosFirst=dwPos;
			CFrame263* pFrame=new CFrame263(&pBuffer[dwPos],flsize-dwPos);
			DWORD dwTime=pFrame->GetTimerValue();
			if( (dwTime>0) && (dwTime<10000) )
				dwDuration+=dwTime;
			InsertFrame(olFrames, pFrame, dwPreviousFrame);
		}
	}

	InitH263Decoder();
	BYTE* pDecodedFrame=(BYTE*)malloc(80000);

	CString csFileSave=m_csPath+"\\"+m_csCallId+".avi";
	CAVIFile	oAviFile(csFileSave,176,144);

	DWORD dwFrameMeanDuration=dwDuration/olFrames.GetCount();
	oAviFile.SetFrameRate(1000/dwFrameMeanDuration);

	CPaintDC dcMem(AfxGetMainWnd());
	for(POSITION pos=olFrames.GetHeadPosition();pos;)
	{
		CFrame263* pFrame=(CFrame263*)olFrames.GetNext(pos);
		RenderFrame(pDecodedFrame, pFrame, flsize, pBuffer);

		BYTE* pDecoded=pFrame->GetDecoded();

		CBitmap bmp;
		bmp.CreateCompatibleBitmap(&dcMem,176,144);

		CDC dcMemory;
		dcMemory.CreateCompatibleDC(&dcMem);
		dcMemory.SelectObject(&bmp);

		if(pDecoded)
		{
			DWORD dwPos=0;
			for(int i=0;i<144;i++)
			{
				for(int j=0;j<176;j++)
				{
					COLORREF clrPixel=RGB(pDecoded[dwPos],pDecoded[dwPos+1],pDecoded[dwPos+2]);

					BYTE bRLeft=j?pDecoded[dwPos-3]:pDecoded[dwPos];
					BYTE bRUp=i?pDecoded[dwPos-(3*176)]:pDecoded[dwPos];
					BYTE bRRight=(j<175)?pDecoded[dwPos+3]:pDecoded[dwPos];
					BYTE bRDown=(i<143)?pDecoded[dwPos+(3*176)]:pDecoded[dwPos];
					BYTE bR=(bRLeft+bRUp+bRRight+bRDown)/4;

					BYTE bGLeft=j?pDecoded[dwPos-3+1]:pDecoded[dwPos+1];
					BYTE bGUp=i?pDecoded[dwPos-(3*176)+1]:pDecoded[dwPos+1];
					BYTE bGRight=(j<175)?pDecoded[dwPos+3+1]:pDecoded[dwPos+1];
					BYTE bGDown=(i<143)?pDecoded[dwPos+(3*176)+1]:pDecoded[dwPos+1];
					BYTE bG=(bGLeft+bGUp+bGRight+bGDown)/4;

					BYTE bBLeft=j?pDecoded[dwPos-3+2]:pDecoded[dwPos+2];
					BYTE bBUp=i?pDecoded[dwPos-(3*176)+2]:pDecoded[dwPos+2];
					BYTE bBRight=(j<175)?pDecoded[dwPos+3+2]:pDecoded[dwPos+2];
					BYTE bBDown=(i<143)?pDecoded[dwPos+(3*176)+2]:pDecoded[dwPos+2];
					BYTE bB=(bBLeft+bBUp+bBRight+bBDown)/4;

					COLORREF clrPixelAntialiasing=RGB(bR,bG,bB);
					dcMemory.SetPixel(j,i,clrPixelAntialiasing);
					dwPos+=3;
				}
			}
		}

		dcMem.BitBlt(0,0,176,144,&dcMemory,0,0,SRCCOPY);

		oAviFile.AddFrame(bmp);
	}

	try { CFile::Remove(csFile); }
	catch(CFileException) {}

	free(pDecodedFrame);
}
