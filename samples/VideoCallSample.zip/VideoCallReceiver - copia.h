// VideoCallReceiver.h: archivo de encabezado
//

class CSIPSocket;
class CFrame263;

class CVideoCallReceiver : public CObject
{
// Construcci�n
public:
	CVideoCallReceiver(CString csLogin, CString csPassword, CString csLocalIP, CString csPath);
	virtual ~CVideoCallReceiver();

	void RegisterAttempt();
	void Register(long lExpires);
	void ReRegister(CString cs401);
	void Unregister();
	void AcceptInvitation(CString csInvitation);
	void SendMultimediaData(CString csAckData);

	void OnReceiveData(char* pBufData,DWORD dwLenData,int nErrorCode);
	static void OnEvent(DWORD dwCookie,UINT nCode,char* pBufData,DWORD dwLenData,int nErrorCode);

	static void OnEventAudio(DWORD dwCookie,UINT nCode,char* pBufData,DWORD dwLenData,int nErrorCode);
	static void OnEventAudioCtrl(DWORD dwCookie,UINT nCode,char* pBufData,DWORD dwLenData,int nErrorCode);
	static void OnEventVideo(DWORD dwCookie,UINT nCode,char* pBufData,DWORD dwLenData,int nErrorCode);
	static void OnEventVideoCtrl(DWORD dwCookie,UINT nCode,char* pBufData,DWORD dwLenData,int nErrorCode);

	void AckBye(CString csBye);

	void Echo(char* pBufData,DWORD dwLenData);
	void SaveAudioData(char* pBufData,DWORD dwLenData);

	void Mirror(char* pBufData,DWORD dwLenData);
	void SaveVideoData(char* pBufData,DWORD dwLenData);

	short DecodeByte(BYTE mulaw);
	void DecodeArray(BYTE* pData, DWORD dwLen, BYTE* pRes);

	void ExportAudio();

	void InsertFrame(CObList& olFrames, CFrame263* pFrame, DWORD& dwPreviousFrame);
	void RenderFrame(BYTE* pDecodedFrame, CFrame263* pFrame, DWORD dwFileSize, BYTE* pVideoBuffer);
	void ExportVideo();

// Implementaci�n
protected:

	CSIPSocket* m_pSocket;

	CSIPSocket* m_pSocketAudio;
	CSIPSocket* m_pSocketAudioCtrl;
	CSIPSocket* m_pSocketVideo;
	CSIPSocket* m_pSocketVideoCtrl;

	UINT m_nPortAudio;
	UINT m_nPortVideo;

	CString	m_csCallId;
	CString	m_csBranch;
	CString	m_csFromTag;
	CString m_csNonce;

	CString m_csStartTime;
	CString m_csFrom;

	CString m_csPassword;
	CString m_csLogin;
	CString m_csLocalIP;
	CString m_csPath;

	bool m_bRegistered;
};
