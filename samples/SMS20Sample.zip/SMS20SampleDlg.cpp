// SMS20SampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SMS20Sample.h"
#include "SMS20SampleDlg.h"

#include "SMS20.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSMS20SampleDlg dialog

CSMS20SampleDlg::CSMS20SampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSMS20SampleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSMS20SampleDlg)
	m_csLogin = _T("");
	m_csPassword = _T("");
	m_csAlias = _T("");
	m_csContact = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSMS20SampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSMS20SampleDlg)
	DDX_Text(pDX, IDC_LOGIN, m_csLogin);
	DDX_Text(pDX, IDC_PASSWORD, m_csPassword);
	DDX_Text(pDX, IDC_ALIAS, m_csAlias);
	DDX_Text(pDX, IDC_CONTACT, m_csContact);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSMS20SampleDlg, CDialog)
	//{{AFX_MSG_MAP(CSMS20SampleDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSMS20SampleDlg message handlers

BOOL CSMS20SampleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_pmsoContacts=NULL;

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSMS20SampleDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSMS20SampleDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSMS20SampleDlg::AddContactToList(CString csContact,CString csNickName)
{
	CString csUserID;
	csUserID.Format("wv:%s@movistar.es",csContact);
	CSMS20Contact* pContact=new CSMS20Contact(csUserID,csNickName);

	m_pmsoContacts->SetAt(csUserID,pContact);
}

void CSMS20SampleDlg::WriteLine(CString csLine)
{
	((CEdit*)GetDlgItem(IDC_CONSOLE))->SetSel(65535,65535);
	((CEdit*)GetDlgItem(IDC_CONSOLE))->ReplaceSel("\r\n"+csLine);
}

void CSMS20SampleDlg::OnOK() 
{
	UpdateData();

	CString csLogin=m_csLogin;
	CString csPwd=m_csPassword;

	CString csMyAlias=m_csAlias;

	CString csContact=m_csContact;

	CSMS20 sms20;
	CString csSession=sms20.Login(csLogin,csPwd);

	WriteLine("SessionID: "+csSession+"\r\n");

	m_pmsoContacts = sms20.Connect(csLogin,csMyAlias);

	WriteLine("Adding contact: "+csContact+"\r\n");
	CString csNickname=sms20.AddContact(csLogin,csContact);
	AddContactToList(csContact,csNickname);

	CString csMessage;
	// Polling until we get " bye"
	while(csMessage!="bye")
	{
		CString csResponse=sms20.Polling();

		if(!csResponse.IsEmpty())
		{
			CSMS20Helper sms20helper;

			// Presence of contacts
			CMapStringToString* pPresents=sms20helper.GetContactPresence(csResponse);
			if(pPresents)
			{
				for(POSITION pos=pPresents->GetStartPosition();pos;)
				{
					CString csId;
					CString csAvailability;
					pPresents->GetNextAssoc(pos,csId,csAvailability);
					if(csAvailability=="AVAILABLE")
					{
						CSMS20Contact* pContact;
						if(m_pmsoContacts->Lookup(csId,(CObject*&)pContact))
						{
							pContact->MakePresent(true);
							WriteLine("\t"+pContact->GetAlias()+" ("+pContact->GetUserID()+") is present\r\n");
						}
						else
							pContact->MakePresent(false);
					}
				}
				pPresents->RemoveAll();
				delete pPresents;
			}

			// To responde to Auth Request from contact
			CString csUserID=sms20helper.SearchAuthorizePresence(csResponse);
			if(!csUserID.IsEmpty())
			{
				CString csTransactionId=sms20helper.SearchTransactionId(csResponse);
				sms20.AuthorizeContact(csUserID,csTransactionId);
			}

			// New message received
			CString csUser;
			CString csReceived=sms20helper.SearchMessage(csResponse);
			int nPosPipe=csReceived.Find("|");
			if(nPosPipe!=-1)
			{
				csUser=csReceived.Left(nPosPipe);
				csMessage=sms20helper.UTF82ASCII((csReceived.Mid(nPosPipe+1)));

				CSMS20Contact* pContact;
				CString csNicknameSender="The other";
				m_pmsoContacts->Lookup(csUser,(CObject*&)pContact);
				if(pContact)
					csNicknameSender=pContact->GetAlias();

				WriteLine(csNicknameSender+": "+csMessage);

				CString csAnswer=csMessage+" to you too";
				sms20.SendMessage(csLogin, csUser, sms20helper.ASCII2UTF8(csAnswer));

				WriteLine(sms20.GetMyAlias()+": "+csAnswer);
			}
		}

		Sleep(3000);
	}

	WriteLine("\r\nDeleting contact: "+csContact+"\r\n");
	sms20.DeleteContact(csLogin, csContact);

	sms20.Disconnect();

	//CDialog::OnOK();
}

void CSMS20SampleDlg::OnDestroy() 
{
	CDialog::OnDestroy();

	if(!m_pmsoContacts)
		return;

	CSMS20Contact* pContact;
	for(POSITION pos=m_pmsoContacts->GetStartPosition();pos;)
	{
		CString csKey;
		m_pmsoContacts->GetNextAssoc(pos,csKey,(CObject*&)pContact);
		m_pmsoContacts->RemoveKey(csKey);

		if(pContact)
			delete pContact;
	}

	delete m_pmsoContacts;
}
