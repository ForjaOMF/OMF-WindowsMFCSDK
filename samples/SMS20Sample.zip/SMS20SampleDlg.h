// SMS20SampleDlg.h : header file
//

#if !defined(AFX_SMS20SAMPLEDLG_H__6E1CB776_4DA2_4194_AE29_70D192E9E043__INCLUDED_)
#define AFX_SMS20SAMPLEDLG_H__6E1CB776_4DA2_4194_AE29_70D192E9E043__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSMS20SampleDlg dialog

class CSMS20SampleDlg : public CDialog
{
// Construction
public:
	CSMS20SampleDlg(CWnd* pParent = NULL);	// standard constructor

	void AddContactToList(CString csContact,CString csNickname);
	void WriteLine(CString csLine);

// Dialog Data
	//{{AFX_DATA(CSMS20SampleDlg)
	enum { IDD = IDD_SMS20SAMPLE_DIALOG };
	CString	m_csLogin;
	CString	m_csPassword;
	CString	m_csAlias;
	CString	m_csContact;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSMS20SampleDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	CMapStringToOb*	m_pmsoContacts;

	// Generated message map functions
	//{{AFX_MSG(CSMS20SampleDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SMS20SAMPLEDLG_H__6E1CB776_4DA2_4194_AE29_70D192E9E043__INCLUDED_)
