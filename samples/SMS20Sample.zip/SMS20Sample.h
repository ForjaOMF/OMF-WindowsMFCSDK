// SMS20Sample.h : main header file for the SMS20SAMPLE application
//

#if !defined(AFX_SMS20SAMPLE_H__38215CF5_5EB9_416C_B3EC_C7B3D9105176__INCLUDED_)
#define AFX_SMS20SAMPLE_H__38215CF5_5EB9_416C_B3EC_C7B3D9105176__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CSMS20SampleApp:
// See SMS20Sample.cpp for the implementation of this class
//

class CSMS20SampleApp : public CWinApp
{
public:
	CSMS20SampleApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSMS20SampleApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSMS20SampleApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SMS20SAMPLE_H__38215CF5_5EB9_416C_B3EC_C7B3D9105176__INCLUDED_)
