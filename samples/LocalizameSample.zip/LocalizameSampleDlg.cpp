// LocalizameSampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LocalizameSample.h"
#include "LocalizameSampleDlg.h"

#include "Localizame.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLocalizameSampleDlg dialog

CLocalizameSampleDlg::CLocalizameSampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLocalizameSampleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLocalizameSampleDlg)
	m_csLocatableLogin = _T("");
	m_csLocatablePassword = _T("");
	m_csLocatorLogin = _T("");
	m_csLocatorPassword = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CLocalizameSampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLocalizameSampleDlg)
	DDX_Text(pDX, IDC_LOCATABLE_LOGIN, m_csLocatableLogin);
	DDX_Text(pDX, IDC_LOCATABLE_PASSWORD, m_csLocatablePassword);
	DDX_Text(pDX, IDC_LOCATOR_LOGIN, m_csLocatorLogin);
	DDX_Text(pDX, IDC_LOCATOR_PASSWORD, m_csLocatorPassword);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CLocalizameSampleDlg, CDialog)
	//{{AFX_MSG_MAP(CLocalizameSampleDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_AUTHORIZE, OnAuthorize)
	ON_BN_CLICKED(IDC_UNAUTHORIZE, OnUnauthorize)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLocalizameSampleDlg message handlers

BOOL CLocalizameSampleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CLocalizameSampleDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CLocalizameSampleDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CLocalizameSampleDlg::OnAuthorize() 
{
	UpdateData();

	BeginWaitCursor();

	CLocalizame* pLoc=new CLocalizame();
	pLoc->Login(m_csLocatableLogin,m_csLocatablePassword);
	pLoc->Authorize(m_csLocatorLogin);
	pLoc->Logout();
	delete pLoc;

	EndWaitCursor();
}

void CLocalizameSampleDlg::OnUnauthorize() 
{
	UpdateData();

	BeginWaitCursor();

	CLocalizame* pLoc=new CLocalizame();
	pLoc->Login(m_csLocatableLogin,m_csLocatablePassword);
	pLoc->Unauthorize(m_csLocatorLogin);
	pLoc->Logout();
	delete pLoc;

	EndWaitCursor();
}

void CLocalizameSampleDlg::OnOK() 
{
	UpdateData();
	SetDlgItemText(IDC_LOCATION,"Locating...");

	BeginWaitCursor();

	CLocalizame* pLoc=new CLocalizame();
	pLoc->Login(m_csLocatorLogin,m_csLocatorPassword);
	CString csLocation=pLoc->Locate(m_csLocatableLogin);
	SetDlgItemText(IDC_LOCATION,csLocation);
	pLoc->Logout();
	delete pLoc;

	EndWaitCursor();
	//CDialog::OnOK();
}
