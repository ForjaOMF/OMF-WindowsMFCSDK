// LocalizameSample.h : main header file for the LOCALIZAMESAMPLE application
//

#if !defined(AFX_LOCALIZAMESAMPLE_H__DB8A9CA6_2A7B_4478_8B94_69E044859163__INCLUDED_)
#define AFX_LOCALIZAMESAMPLE_H__DB8A9CA6_2A7B_4478_8B94_69E044859163__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CLocalizameSampleApp:
// See LocalizameSample.cpp for the implementation of this class
//

class CLocalizameSampleApp : public CWinApp
{
public:
	CLocalizameSampleApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLocalizameSampleApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CLocalizameSampleApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOCALIZAMESAMPLE_H__DB8A9CA6_2A7B_4478_8B94_69E044859163__INCLUDED_)
