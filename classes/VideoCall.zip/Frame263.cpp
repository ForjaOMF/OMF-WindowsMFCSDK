//********************************************************************
//**					Ibys Inform�tica & Telecomunicaciones S.A.	**
//**	NOMBRE:			Frame263.cpp								**
//**	DESCRIPCI�N:	Clase de manejo de frame de v�deo H.263		**
//**	AUTOR:			Francisco Javier Rodr�guez					**
//**																**
//**	VERS.	FECHA		COMENTARIO								**
//**  ----  --------   ---------------------------------------------**
//**	1.0		01/12/05	Primera versi�n sin revisiones 			**
//********************************************************************

#include "stdafx.h"
#include "Frame263.h"

//********************************************************************
//**	CLASE:			CFrame263		 							**
//** 	DESCRIPCI�N:	Clase de manejo de frame de v�deo H.263		**
//********************************************************************

//********************************************************************
//*		Constructor/Destructor										**
//********************************************************************
CFrame263::	CFrame263(BYTE* pBuffer,DWORD dwBufferSize)
{
	m_dwFrameNumber=-1;

	DWORD dwSize=0;
	DWORD dwValue;
	DWORD dwPos=3;
	while( (dwPos<dwBufferSize-3) && (!dwSize) )
	{
		dwValue=pBuffer[dwPos];
		dwValue<<=8;
		dwValue+=pBuffer[dwPos+1];
		dwValue<<=8;
		dwValue+=pBuffer[dwPos+2];
		dwValue>>=2;

		if(dwValue==0x20)
			dwSize=dwPos;

		dwPos++;
	}

	SetBuffer(pBuffer,dwSize);

	m_pDecoded=NULL;
	m_dwDecodedSize=0;
}

CFrame263::~CFrame263()
{
	if(m_pDecoded)
	{
		free(m_pDecoded);
		m_pDecoded=NULL;
	}
}

//	Rellena el buffer del frame
void CFrame263::SetBuffer(BYTE* pBuffer,DWORD dwSize)
{
	m_pBuffer=pBuffer;
	m_dwSize=dwSize;

	m_dwFrameNumber=ObtainFrameNumber();
	m_dwTimerValue=ObtainTimeDiff();
}

//	Obtiene el n�mero de frame
DWORD CFrame263::ObtainFrameNumber()
{
	BYTE bt2=m_pBuffer[2];
	BYTE bt3=m_pBuffer[3];

	DWORD dwFrameNumber;
	dwFrameNumber=bt2&0x3;
	dwFrameNumber<<=8;
	dwFrameNumber+=bt3;
	dwFrameNumber>>=2;

	return dwFrameNumber;
}

//	Obtiene la diferencia de tiempo respecto al frame anterior
DWORD CFrame263::ObtainTimeDiff()
{
	BYTE bt2=m_pBuffer[2];
	BYTE bt3=m_pBuffer[3];

	DWORD dwTimeDiff;
	dwTimeDiff=bt2&0x3;
	dwTimeDiff<<=8;
	dwTimeDiff+=bt3;
	dwTimeDiff>>=2;

	return dwTimeDiff;
}

// Rellena el buffer con el frame decodificado
void CFrame263::SetDecoded(BYTE* pDecoded,DWORD dwDecodedSize)
{
	m_pDecoded=(BYTE*)malloc(dwDecodedSize);
	memset(m_pDecoded,0,dwDecodedSize);

	memcpy(m_pDecoded,pDecoded,dwDecodedSize);

	m_dwDecodedSize=dwDecodedSize;
}
