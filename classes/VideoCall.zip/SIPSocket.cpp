// SIPSocket.cpp : implementation file
//

#include "stdafx.h"
#include "SIPSocket.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSIPSocket
CSIPSocket::CSIPSocket() : CAsyncSocket()
{
	m_pCallbackFunction = NULL;
	m_dwCookie = 0;
}

CSIPSocket::CSIPSocket(tagCallbackFn pCallbackFunction,DWORD dwCookie) : CAsyncSocket()
{
	m_pCallbackFunction = pCallbackFunction;
	m_dwCookie = dwCookie;
}

CSIPSocket::~CSIPSocket()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CSIPSocket, CAsyncSocket)
	//{{AFX_MSG_MAP(CSIPSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CSIPSocket member functions

void CSIPSocket::OnReceive(int nErrorCode) 
{
	BYTE data[65000];
	memset(data,0,65000);
	int nLong=0;
	int nReceived=0;
	do
	{
		nLong=Receive(&data[nReceived],65000);
		if(nLong>0)
			nReceived+=nLong;
	}
	while(nLong>0);

	if(m_pCallbackFunction)
		m_pCallbackFunction(m_dwCookie,FSOCK_RECEIVE,(char*)data,nReceived,nErrorCode);

	CAsyncSocket::OnReceive(nErrorCode);
}

void CSIPSocket::OnConnect(int nErrorCode) 
{
	if(m_pCallbackFunction)
		m_pCallbackFunction(m_dwCookie,FSOCK_CONNECT,NULL,0,nErrorCode);

	CAsyncSocket::OnConnect(nErrorCode);
}

void CSIPSocket::OnAccept(int nErrorCode) 
{
	if(m_pCallbackFunction)
		m_pCallbackFunction(m_dwCookie,FSOCK_ACCEPT,NULL,0,nErrorCode);

	CAsyncSocket::OnAccept(nErrorCode);
}

void CSIPSocket::OnClose(int nErrorCode) 
{
	if(m_pCallbackFunction)
		m_pCallbackFunction(m_dwCookie,FSOCK_CLOSE,NULL,0,nErrorCode);
}
