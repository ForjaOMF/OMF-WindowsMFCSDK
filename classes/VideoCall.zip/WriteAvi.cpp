/**************************************************************************
 *
 *  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 *  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 *  PURPOSE.
 *
 *  Copyright (C) 1992 - 1996 Microsoft Corporation.  All Rights Reserved.
 *
 **************************************************************************/
/****************************************************************************
 *
 *  WRITEAVI.C
 *
 *  Creates the file OUTPUT.AVI, an AVI file consisting of a rotating clock
 *  face.  This program demonstrates using the functions in AVIFILE.DLL
 *  to make writing AVI files simple.
 *
 *  This is a stripped-down example; a real application would have a user
 *  interface and check for errors.
 *
 ***************************************************************************/
#include "stdafx.h"
#include <windowsx.h>
#include <memory.h>
#include <mmsystem.h>
#include <vfw.h>

#include "writeavi.h"

static HANDLE  MakeDib( HBITMAP hbitmap, UINT bits )
{
	HANDLE              hdib ;
	HDC                 hdc ;
	BITMAP              bitmap ;
	UINT                wLineLen ;
	DWORD               dwSize ;
	DWORD               wColSize ;
	LPBITMAPINFOHEADER  lpbi ;
	LPBYTE              lpBits ;
	
	GetObject(hbitmap,sizeof(BITMAP),&bitmap) ;

	//
	// DWORD align the width of the DIB
	// Figure out the size of the colour table
	// Calculate the size of the DIB
	//
	wLineLen = (bitmap.bmWidth*bits+31)/32 * 4;
	wColSize = sizeof(RGBQUAD)*((bits <= 8) ? 1<<bits : 0);
	dwSize = sizeof(BITMAPINFOHEADER) + wColSize +
		(DWORD)(UINT)wLineLen*(DWORD)(UINT)bitmap.bmHeight;

	//
	// Allocate room for a DIB and set the LPBI fields
	//
	hdib = GlobalAlloc(GHND,dwSize);
	if (!hdib)
		return hdib ;

	lpbi = (LPBITMAPINFOHEADER)GlobalLock(hdib) ;

	lpbi->biSize = sizeof(BITMAPINFOHEADER) ;
	lpbi->biWidth = bitmap.bmWidth ;
	lpbi->biHeight = bitmap.bmHeight ;
	lpbi->biPlanes = 1 ;
	lpbi->biBitCount = (WORD) bits ;
	lpbi->biCompression = BI_RGB ;
	lpbi->biSizeImage = dwSize - sizeof(BITMAPINFOHEADER) - wColSize ;
	lpbi->biXPelsPerMeter = 0 ;
	lpbi->biYPelsPerMeter = 0 ;
	lpbi->biClrUsed = (bits <= 8) ? 1<<bits : 0;
	lpbi->biClrImportant = 0 ;

	//
	// Get the bits from the bitmap and stuff them after the LPBI
	//
	lpBits = (LPBYTE)(lpbi+1)+wColSize ;

	hdc = CreateCompatibleDC(NULL) ;

	GetDIBits(hdc,hbitmap,0,bitmap.bmHeight,lpBits,(LPBITMAPINFO)lpbi, DIB_RGB_COLORS);

	// Fix this if GetDIBits messed it up....
	lpbi->biClrUsed = (bits <= 8) ? 1<<bits : 0;

	DeleteDC(hdc) ;
	GlobalUnlock(hdib);

	return hdib ;
}

CAVIFile::CAVIFile(LPCTSTR lpszFileName, int xdim, int ydim)
 :	FName(lpszFileName),
	xDim(xdim), yDim(ydim), bOK(true), nFrames(0)
{
	pfile = NULL;
	ps = NULL;
	psCompressed = NULL;
	psAudio = NULL;
	aopts[0] = &opts;

	m_dwFrameRate=25;

	WORD wVer = HIWORD(VideoForWindowsVersion());
	if (wVer < 0x010A)
	{
		// oops, we are too old, blow out of here
		bOK = false;
	}
	else
	{
		AVIFileInit();
	}
}

CAVIFile::~CAVIFile()
{
	if (ps)
		AVIStreamClose(ps);

	if (psCompressed)
		AVIStreamClose(psCompressed);

	if (psAudio)
		AVIStreamClose(psAudio);

	if (pfile)
		AVIFileClose(pfile);

	WORD wVer = HIWORD(VideoForWindowsVersion());
	if (wVer >= 0x010A)
	{
		AVIFileExit();
	}
}

bool CAVIFile::AddFrame(CBitmap& bmp)
{
	HRESULT hr;

	if (!bOK)
		return false;
	LPBITMAPINFOHEADER alpbi = (LPBITMAPINFOHEADER)GlobalLock(MakeDib(bmp, 24));
	if (alpbi == NULL)
		return false;
	if (xDim>=0 && xDim != alpbi->biWidth)
	{
		GlobalFreePtr(alpbi);
		return false;
	}
	if (yDim>=0 && yDim != alpbi->biHeight)
	{
		GlobalFreePtr(alpbi);
		return false;
	}
	xDim = alpbi->biWidth;
	yDim = alpbi->biHeight;
	if (nFrames == 0)
	{
		hr = AVIFileOpen(&pfile,		    // returned file pointer
			       FName,							// file name
				   OF_WRITE | OF_CREATE,		    // mode to open file with
				   NULL);							// use handler determined
													// from file extension....
		if (hr != AVIERR_OK)
		{
			GlobalFreePtr(alpbi);
			bOK = false;
			return false;
		}
		_fmemset(&strhdr, 0, sizeof(strhdr));
		strhdr.fccType                = streamtypeVIDEO;// stream type
		strhdr.fccHandler             = 0;
		strhdr.dwScale                = 1;
		strhdr.dwRate                 = m_dwFrameRate;		    // 15 fps
		strhdr.dwSuggestedBufferSize  = alpbi->biSizeImage;
		SetRect(&strhdr.rcFrame, 0, 0,		    // rectangle for stream
			(int) alpbi->biWidth,
			(int) alpbi->biHeight);

		// And create the stream;
		hr = AVIFileCreateStream(pfile,		    // file pointer
						         &ps,		    // returned stream pointer
								 &strhdr);	    // stream header
		if (hr != AVIERR_OK)
		{
			GlobalFreePtr(alpbi);
			bOK = false;
			return false;
		}

		_fmemset(&opts, 0, sizeof(opts));

		opts.fccHandler = mmioFOURCC('D','I','B',' ');
		opts.dwFlags = 8;

		/*if (!AVISaveOptions(NULL, 0, 1, &ps, (LPAVICOMPRESSOPTIONS FAR *) &aopts))
		{
			GlobalFreePtr(alpbi);
			bOK = false;
			return false;
		}*/

		hr = AVIMakeCompressedStream(&psCompressed, ps, &opts, NULL);
		if (hr != AVIERR_OK)
		{
			GlobalFreePtr(alpbi);
			bOK = false;
			return false;
		}

		hr = AVIStreamSetFormat(psCompressed, 0,
					   alpbi,	    // stream format
				       alpbi->biSize +   // format size
				       alpbi->biClrUsed * sizeof(RGBQUAD));
		if (hr != AVIERR_OK)
		{
			GlobalFreePtr(alpbi);
			bOK = false;
			return false;
		}
	}

	// Jetzt eigentliches Schreiben
	hr = AVIStreamWrite(psCompressed,	// stream pointer
		nFrames,				// time of this frame
		1,				// number to write
		(LPBYTE) alpbi +		// pointer to data
			alpbi->biSize +
			alpbi->biClrUsed * sizeof(RGBQUAD),
			alpbi->biSizeImage,	// size of this frame
		AVIIF_KEYFRAME,			 // flags....
		NULL,
		NULL);
	if (hr != AVIERR_OK)
	{
		GlobalFreePtr(alpbi);
		bOK = false;
		return false;
	}

	GlobalFreePtr(alpbi);

	nFrames++;
	return true;
}

WAVEFORMATEX* CAVIFile::BuildWaveFormat(WORD nChannels, DWORD nFrequency, WORD nBits)
{
	WAVEFORMATEX* pcmWaveFormat=(WAVEFORMATEX*)malloc(sizeof(WAVEFORMATEX));
	pcmWaveFormat->wFormatTag = WAVE_FORMAT_PCM;
	pcmWaveFormat->nChannels = nChannels;
	pcmWaveFormat->nSamplesPerSec = nFrequency;
	pcmWaveFormat->nAvgBytesPerSec = nFrequency * nChannels * nBits / 8;
	pcmWaveFormat->nBlockAlign = nChannels * nBits / 8;
	pcmWaveFormat->wBitsPerSample = nBits;

	return pcmWaveFormat;
}	

bool CAVIFile::InsertAudio(BYTE* pBuff,DWORD dwSize)
{
	if(!pfile)
		return false;

	HRESULT hr;
	WAVEFORMATEX* pFormat=BuildWaveFormat(1, 8000, 16);

	_fmemset(&strhdr, 0, sizeof(strhdr));
	strhdr.fccType			= streamtypeAUDIO;// stream type
	strhdr.fccHandler		= mmioFOURCC('W','A','V','E');
	strhdr.dwScale			= pFormat->nBlockAlign;
	strhdr.dwRate			= pFormat->nSamplesPerSec*pFormat->nBlockAlign;
	strhdr.dwSampleSize		= pFormat->nBlockAlign;
    strhdr.dwQuality		= (DWORD)-1;
	strhdr.dwLength			= 10;
	strhdr.dwStart			= 0;

	// And create the stream;
	hr = AVIFileCreateStream(pfile,		    // file pointer
						     &psAudio,		    // returned stream pointer
							 &strhdr);	    // stream header
	if (hr != AVIERR_OK)
	{
		free(pFormat);
		return false;
	}

	hr = AVIStreamSetFormat(psAudio, 0, pFormat, sizeof(WAVEFORMATEX));
	if (hr != AVIERR_OK)
	{
		free(pFormat);
		return false;
	}

	unsigned long numbytes = dwSize;
	unsigned long numsamps = numbytes*8 / pFormat->wBitsPerSample;
	hr = AVIStreamWrite(psAudio,
		0,
		numsamps,
		pBuff,
		numbytes,
		AVIIF_KEYFRAME,
		NULL,
		NULL);
	if (hr != AVIERR_OK)
	{
		free(pFormat);
		return false;
	}

	free(pFormat);
	return true;
}

/*HRESULT CAVIFile::AddAviWav(const char *src)
{
	if (avi==NULL)
		return AVIERR_BADHANDLE;
	TAviUtil *au = (TAviUtil*)avi;
	if (au->iserr)
		return AVIERR_ERROR;

	char *buf=0; WavChunk *wav = (WavChunk*)src;
	if (flags==SND_FILENAME)
	{
		HANDLE hf=CreateFile(src,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,0,NULL);
		if (hf==INVALID_HANDLE_VALUE)
		{
			au->iserr=true;
			return AVIERR_FILEOPEN;
		}
		DWORD size = GetFileSize(hf,NULL);
		buf = new char[size];
		DWORD red;
		ReadFile(hf,buf,size,&red,NULL);
		CloseHandle(hf);
		wav = (WavChunk*)buf;
	}

	// check that format doesn't clash
	bool badformat=false;
	if (au->wfx.nChannels==0)
	{
		au->wfx.wFormatTag=wav->fmt.wFormatTag;
		au->wfx.cbSize=0;
		au->wfx.nAvgBytesPerSec=wav->fmt.dwAvgBytesPerSec;
		au->wfx.nBlockAlign=wav->fmt.wBlockAlign;
		au->wfx.nChannels=wav->fmt.wChannels;
		au->wfx.nSamplesPerSec=wav->fmt.dwSamplesPerSec;
		au->wfx.wBitsPerSample=wav->fmt.wBitsPerSample;
	}
	else
	{
		if (au->wfx.wFormatTag!=wav->fmt.wFormatTag)
			badformat=true;
		if (au->wfx.nAvgBytesPerSec!=wav->fmt.dwAvgBytesPerSec)
			badformat=true;
		if (au->wfx.nBlockAlign!=wav->fmt.wBlockAlign)
			badformat=true;
		if (au->wfx.nChannels!=wav->fmt.wChannels)
			badformat=true;
		if (au->wfx.nSamplesPerSec!=wav->fmt.dwSamplesPerSec)
			badformat=true;
		if (au->wfx.wBitsPerSample!=wav->fmt.wBitsPerSample)
			badformat=true;
	}
	if (badformat)
	{
		if (buf!=0)
			delete[] buf;
		return AVIERR_BADFORMAT;}

	if (au->as==0) // create the stream if necessary
	{
		AVISTREAMINFO ahdr;
		ZeroMemory(&ahdr,sizeof(ahdr));
		ahdr.fccType=streamtypeAUDIO;
		ahdr.dwScale=au->wfx.nBlockAlign;
		ahdr.dwRate=au->wfx.nSamplesPerSec*au->wfx.nBlockAlign; 
		ahdr.dwSampleSize=au->wfx.nBlockAlign;
		ahdr.dwQuality=(DWORD)-1;
		HRESULT hr = AVIFileCreateStream(au->pfile, &au->as, &ahdr);
		if (hr!=AVIERR_OK)
		{
			if (buf!=0)
				delete[] buf;
			au->iserr=true; return hr;
		}
		hr = AVIStreamSetFormat(au->as,0,&au->wfx,sizeof(WAVEFORMATEX));
		if (hr!=AVIERR_OK)
		{
			if (buf!=0)
				delete[] buf;
			au->iserr=true; return hr;
		}
	}

	// now we can write the data
	unsigned long numbytes = wav->dat.size;
	unsigned long numsamps = numbytes*8 / au->wfx.wBitsPerSample;
	HRESULT hr = AVIStreamWrite(au->as,au->nsamp,numsamps,wav->dat.data,numbytes,0,NULL,NULL);
	if (buf!=0)
		delete[] buf;
	if (hr!=AVIERR_OK)
	{
		au->iserr=true;
		return hr;
	}
	au->nsamp+=numsamps;
	return S_OK;
}*/
