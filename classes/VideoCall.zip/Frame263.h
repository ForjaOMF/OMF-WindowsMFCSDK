//********************************************************************
//**					Ibys Inform�tica & Telecomunicaciones S.A.	**
//**	NOMBRE:			Frame263.h									**
//**	DESCRIPCI�N:	Clase de manejo de frame de v�deo H.263		**
//**	AUTOR:			Francisco Javier Rodr�guez					**
//**																**
//**	VERS.	FECHA		COMENTARIO								**
//**  ----  --------   ---------------------------------------------**
//**	1.0		01/12/05	Primera versi�n sin revisiones 			**
//********************************************************************

#ifndef FRAME_H263
#define FRAME_H263

//********************************************************************
//**	CLASE:			CFrame263		 							**
//** 	DESCRIPCI�N:	Clase de manejo de frame de v�deo H.263		**
//********************************************************************

class CFrame263 : public CObject
{
	DWORD		m_dwFrameNumber;	// N�mero de frame
	BYTE*		m_pBuffer;			// Direcci�n del frame dentro del buffer
	DWORD		m_dwSize;			// Tama�o del buffer

	DWORD		m_dwTimerValue;		// Diferencia de tiempo respecto al frame anterior
	BYTE*		m_pDecoded;			// Buffer con el frame decodificado
	DWORD		m_dwDecodedSize;	// Tama�o del buffer con el frame decodificado

	DWORD	ObtainTimeDiff();		// Obtiene la diferencia de tiempo respecto al frame anterior
	DWORD	ObtainFrameNumber();	// Obtiene el n�mero de frame

public:
	CFrame263(BYTE* pBuffer,DWORD dwBufferSize);
	~CFrame263();

			// N�mero de frame
	DWORD	GetFrameNumber(){return m_dwFrameNumber;};

			// Rellena el buffer del frame
	void	SetBuffer(BYTE* pBuffer,DWORD dwSize);

			// Direcci�n del frame dentro del buffer
	BYTE*	GetBuffer(){return m_pBuffer;};
	DWORD	GetBufferSize(){return m_dwSize;};
	
			// Get/Set de la diferencia de tiempo respecto al frame anterior
	void	SetTimerValue(DWORD dwTimerValue){m_dwTimerValue=dwTimerValue;};
	DWORD	GetTimerValue(){return m_dwTimerValue;};

			// Rellena el buffer con el frame decodificado
	void	SetDecoded(BYTE* pDecoded,DWORD dwDecodedSize);

			// Direcci�n del buffer con el frame decodificado
	BYTE*	GetDecoded(){return m_pDecoded;};
			// Tama�o del buffer con el frame decodificado
	DWORD	GetDecodedSize(){return m_dwDecodedSize;};
};

#endif //FRAME_H263
